# ft_package

A sample test package.

- Name: **ft_package**
- Version: **0.0.1**
- Author: **eagle** <eagle@42.fr>
- License: **MIT**
- Homepage: https://github.com/eagle/ft_package

## Usage

```bash
python -c "from ft_package import hello; print(hello('chou'))"
# Hello, chou!

ft-hello chou
# Hello, chou!
